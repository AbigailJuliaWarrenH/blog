<div class="card mb-3">
  <div class="card-header">
    <h3 class="card-title">
        <?php echo e($post->title); ?>

    </h3>
    <small>by <?php echo e($post->user->name); ?></small>
    <small><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($post->created_at))->diffForHumans()); ?></small>
    <div><i class="fas fa-tag"></i> <?php echo e($post->category->name); ?></div>
  </div>
  <div class="card-body">
    <div class="post-content">
      <?php echo ($post->content); ?>

    </div>
    <?php if($post->user->id == Auth::id()): ?>
      
      
      <a href="#" onclick="event.preventDefault(); document.getElementById('form-post-edit-<?php echo e($post->id); ?>').submit();">
        edit
      </a>
      <form id="form-post-edit-<?php echo e($post->id); ?>" action="/posts/<?php echo e($post->id); ?>/edit" method="POST" style="display: none;">
          <?php echo e(csrf_field()); ?>

      </form>
      <span>&middot;</span>
      <a href="#" onclick="event.preventDefault(); document.getElementById('form-post-delete-<?php echo e($post->id); ?>').submit();">
        delete
      </a>
      <form id="form-post-delete-<?php echo e($post->id); ?>" action="/posts/<?php echo e($post->id); ?>" method="POST" style="display: none;">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>

      </form>
    <?php endif; ?>
  </div>
  <div class="card-footer">
  	
    <ul class="list-group">
      <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('comments.comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo $__env->make('comments.comment_edit_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('comments.comment_create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>