<?php $__env->startSection('content'); ?>

<div class="jumbotron text-white jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Welcome, <?php echo e(Auth::user()->name); ?></h1>
     <p class="lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
  </div>
</div>



<div class="container-fluid">
    <div class="row">
        <div class="col-md-9" style="background-color: lightgreen">
            left - My Posts
            <?php echo $__env->make('posts.create_post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php $__currentLoopData = Auth::user()->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('posts.post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <div class="col-md-3" style="background-color: lightblue">
            right - My Images
            <?php echo $__env->make('images.right_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>