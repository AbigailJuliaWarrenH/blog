<li class="list-group-item comment">
	<div class="comment-header">
		<?php echo e($comment->user->name); ?>

	</div>
	<div class="comment-body">
		<?php echo e($comment->content); ?>

		<div>
			<?php if($comment->user->id == Auth::id()): ?>
				<a class="a-comment-edit" data-comment_id="<?php echo e($comment->id); ?>" data-toggle="modal" href="#modal-comment-edit">edit</a>
				<span>&middot;</span>
				<a href="#"
                    onclick="event.preventDefault();
                             document.getElementById('form-comment-delete-<?php echo e($comment->id); ?>').submit();">
					delete
				</a>
                <form id="form-comment-delete-<?php echo e($comment->id); ?>" action="/comments/<?php echo e($comment->id); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                </form>
			<?php endif; ?>
		</div>
	</div>
</li>