<form action="/comments/" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PATCH')); ?>

    <div class="form-group">
      
      <textarea required class="form-control" rows="2" id="edit-comment-content" name="content"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>