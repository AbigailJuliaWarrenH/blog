<?php $__env->startSection('content'); ?>
<div class="card mb-3">
  <div class="card-body">
    <form action="/posts/<?php echo e($post->id); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PATCH')); ?>

        <div class="form-group">
          <label for="title">Title:</label>
          <input required type="text" class="form-control" id="create-post-title" value="<?php echo e($post->title); ?>" name="title">
        </div>
        <div class="form-group">
            <label for="category">Category:</label>
            <select class="form-control" id="create-post-category" value="<?php echo e($post->category->id); ?>" name="category_id">
                <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
          <label for="content">Content:</label>
          <textarea required class="form-control" rows="5" id="create-post-content" name="content"><?php echo e($post->content); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>