
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>






<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script src="/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
<script>
    $('textarea[id$="post-content"]').ckeditor();
    // $('.textarea').ckeditor(); // if class is prefered.
</script>


<script src="<?php echo e(asset('js/dropzone.js')); ?>"></script>








<!-- custom external script -->
<script src="<?php echo e(asset('js/script.js')); ?>"></script>