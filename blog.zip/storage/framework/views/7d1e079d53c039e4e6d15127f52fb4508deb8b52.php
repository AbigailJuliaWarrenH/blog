<div class="card mb-3">
  <div class="card-body">
    <h3>Upload Image</h3>
    
    
    <form id="form-upload-image" method="post" enctype="multipart/form-data" action="/images/upload">
      <?php echo e(csrf_field()); ?>

      <input id="input-upload-image" name="file[]" type="file" multiple />
      
    </form>

  </div>
</div>

<div class="card mb-3">
  <div class="card-body">
    <h3>Uploaded Images</h3>
    <div id="uploaded-images" style="text-align: center;"></div>
  </div>
</div>