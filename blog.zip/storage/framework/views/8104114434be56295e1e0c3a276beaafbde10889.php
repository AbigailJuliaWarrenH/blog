<div class="card mb-3">
  <div class="card-body">
    <h3>Create Post</h3>
    <form action="/posts" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="title">Title:</label>
          <input required type="text" class="form-control" id="create-post-title" name="title">
        </div>
        <div class="form-group">
            <label for="category">Category:</label>
            <select class="form-control" id="create-post-category" name="category_id">
                <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
          <label for="content">Content:</label>
          <textarea required class="form-control" rows="5" id="create-post-content" name="content"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Post</button>
    </form>
  </div>
</div>